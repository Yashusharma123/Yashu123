<?php

$db=new mysqli('localhost','root','','quiz') or die("not connected");


?>